package com.anyoarena.local;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 27;
    private static final Pattern PRIVATE_IP = Pattern.compile(
        "^(127\\.0\\.0\\.1|10\\.(?:\\d{1,3}\\.){2}\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|172\\.(?:1[6-9]|2[0-9]|3[01])\\.\\d{1,3}\\.\\d{1,3}):8080$");
    private WebView web;
    private ValueCallback<Uri[]> imageCallback;
    private String origin;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        showSplash();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(16), dp(8), dp(16), dp(8));
        splash.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xff090d19, 0xff15223b, 0xff090d19}));
        ImageView art = new ImageView(this);
        art.setImageResource(com.anyoarena.local.R.drawable.brand);
        art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splash.addView(art, new LinearLayout.LayoutParams(dp(300), 0, 1));
        TextView label = new TextView(this);
        label.setText("ENTER THE ARENA"); label.setTextColor(0xffffce79);
        label.setTextSize(14); label.setGravity(Gravity.CENTER); label.setLetterSpacing(.18f);
        splash.addView(label);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(false); progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xffff7948));
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(250), dp(5));
        progressParams.setMargins(0, dp(16), 0, dp(20));
        splash.addView(progress, progressParams);
        setContentView(splash);
        progress.animate().setDuration(1300).withEndAction(() -> {}).start();
        android.animation.ValueAnimator bar = android.animation.ValueAnimator.ofInt(0, 100);
        bar.setDuration(1450);
        bar.addUpdateListener(a -> progress.setProgress((int)a.getAnimatedValue()));
        bar.start();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing() && !isDestroyed()) showStart();
        }, 1550);
    }

    private void showStart() {
        if (web != null) { web.destroy(); web = null; }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setPadding(dp(22), dp(16), dp(28), dp(16));
        layout.setGravity(Gravity.CENTER);
        layout.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xff120d1a, 0xff10233b, 0xff090d18}));
        ImageView art = new ImageView(this);
        art.setImageResource(com.anyoarena.local.R.drawable.brand);
        art.setScaleType(ImageView.ScaleType.FIT_CENTER);
        layout.addView(art, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(20), 0, 0, 0);
        layout.addView(actions, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        TextView title = new TextView(this);
        title.setText("CHOOSE YOUR FIGHT"); title.setTextSize(23); title.setTextColor(0xffffcc6b);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        actions.addView(title);
        TextView help = new TextView(this);
        help.setText("The arena is yours. Fight the AI right here, even offline.");
        help.setTextColor(0xffd5deed); help.setTextSize(15);
        LinearLayout.LayoutParams helpParams = new LinearLayout.LayoutParams(-1, -2);
        helpParams.setMargins(0, dp(8), 0, dp(16));
        actions.addView(help, helpParams);
        android.widget.Button solo = new android.widget.Button(this);
        solo.setText("PLAY 1 VS AI · OFFLINE");
        solo.setTextColor(Color.WHITE);
        solo.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffa7231f));
        actions.addView(solo, new LinearLayout.LayoutParams(-1, dp(56)));
        solo.setOnClickListener(v -> { origin = "file:///android_asset"; openGame(); });
        android.widget.Button multiplayer = new android.widget.Button(this);
        multiplayer.setText("MULTIPLAYER · SAME WI-FI");
        multiplayer.setTextColor(Color.WHITE);
        multiplayer.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff214e82));
        LinearLayout.LayoutParams multiParams = new LinearLayout.LayoutParams(-1, dp(52));
        multiParams.setMargins(0, dp(10), 0, 0);
        actions.addView(multiplayer, multiParams);
        multiplayer.setOnClickListener(v -> showConnect());
        setContentView(layout);
    }

    private void showConnect() {
        if (web != null) { web.destroy(); web = null; }
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(42, 40, 42, 20);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setBackgroundColor(0xff111b2c);
        TextView title = new TextView(this);
        title.setText("ANYO ARENA"); title.setTextSize(30); title.setTextColor(0xffffcc6b);
        layout.addView(title);
        TextView help = new TextView(this);
        help.setText("Connect to the game host on the same Wi-Fi. Enter the host's local address (example: 192.168.1.5). The host must run server.py.");
        help.setTextColor(0xffd5deed); help.setTextSize(16);
        layout.addView(help);
        EditText address = new EditText(this);
        address.setSingleLine(); address.setHint("192.168.1.5"); address.setTextColor(0xffffffff);
        address.setHintTextColor(0xff8796aa);
        address.setText(getPreferences(MODE_PRIVATE).getString("host", ""));
        layout.addView(address);
        android.widget.Button connect = new android.widget.Button(this);
        connect.setText("CONNECT TO GAME"); layout.addView(connect);
        TextView error = new TextView(this); error.setTextColor(0xffff8c85); layout.addView(error);
        connect.setOnClickListener(v -> {
            String host = address.getText().toString().trim().replaceFirst("^https?://", "").replaceFirst("/.*$", "");
            if (!host.contains(":")) host += ":8080";
            if (!PRIVATE_IP.matcher(host).matches()) {
                error.setText("Enter a private Wi-Fi IP address from the host, such as 192.168.1.5"); return;
            }
            getPreferences(MODE_PRIVATE).edit().putString("host", host.replace(":8080", "")).apply();
            origin = "http://" + host;
            openGame();
        });
        setContentView(layout);
    }

    private void openGame() {
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith(origin + "/") && !url.equals(origin);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (failingUrl.startsWith(origin)) new AlertDialog.Builder(MainActivity.this)
                    .setMessage("Cannot open the game.\n\n" + description)
                    .setPositiveButton("BACK", (dialog, which) -> showStart()).show();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (imageCallback != null) imageCallback.onReceiveValue(null);
                imageCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.setType("image/*"); pick.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(pick, "Choose fighter photo"), PICK_IMAGE);
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(origin.startsWith("file:") ? origin + "/index.html" : origin + "/");
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_IMAGE && imageCallback != null) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            imageCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            imageCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (web != null) new AlertDialog.Builder(this).setMessage("Return to game modes?")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("BACK", (d, w) -> showStart()).show();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (imageCallback != null) imageCallback.onReceiveValue(null);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
