# Anyo Arena — local fighting prototype

Playable modes: Solo vs AI, local 1v1, and local 2v2 with four simultaneous fighters. Players can upload a photo, choose a costume palette, switch between Bilis and Bigat stance, and use light, heavy, guard, and skill actions. Three original arenas are included.

## Start

Requires Python 3.10+ and `aiohttp`.

```bash
python3 -m pip install -r requirements.txt
python3 server.py
```

Open `http://localhost:8080` on the host. Other devices connected to the **same Wi-Fi or hotspot** open the host's displayed local address (for example `http://192.168.1.5:8080`). The host creates a room and shares its five-character code. No external game server or Internet connection is required after dependencies are installed. The host machine must remain running. If devices cannot connect, check the host firewall and whether the Wi-Fi permits device-to-device traffic.

On a phone, play with the on-screen controls. On a keyboard: A/D or arrows to move, J light, K heavy, L skill, S guard, Shift to switch stance. The skill costs 45 meter. First team to win two rounds wins the match. The host clicks **Next Round / Rematch** between rounds.

## Current scope

The uploaded image is cropped locally to a small portrait and used as the character's face. The fighting body and animation are drawn by the game. This prototype does not generate a fully animated character from a photo and does not use an AI image model. The photo stays in the local room's memory while the room is active; it is shared with participants on the LAN, so use an image you have permission to share.

The combat server owns health, positions, hits and round results. The local network implementation is intended for trusted players on the same Wi-Fi. There is no Bluetooth mode, account system, persistence, or ranked play yet. This is an early playable prototype with simple combat and AI; it is not a finished competitive fighting game.

## Android installation

The `android/` folder contains an Android app project that opens this game on phones and supports choosing a fighter photo. See `android/README.md` for build and install steps. The Android app connects to the Python host; it does not run the server itself. This source package does not contain a compiled APK.
